﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace keyboardhook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        GlobalKeyboardHook globalHook;
        private void Form1_Load(object sender, EventArgs e)
        {
            globalHook = new GlobalKeyboardHook();
            globalHook.KeyDown += new KeyEventHandler(globalHook_KeyDown);
            foreach (Keys key in Enum.GetValues(typeof(Keys)))
                globalHook.HookedKeys.Add(key);



        }

       
        public void globalHook_KeyDown(object sender, KeyEventArgs e)
        {

            textBox1.Text += ((char)e.KeyValue).ToString();
           
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            globalHook.hook();
            MessageBox.Show("Ctrl + K \nsaves to file");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            globalHook.unhook();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            globalHook.unhook();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode.ToString() == "K")
            {
                using (Stream str = new FileStream(@"C:\Users\ACK Nkili\Documents\log\log.txt", FileMode.Create, FileAccess.Write))
                {

                    using (StreamWriter writer = new StreamWriter(str))
                    {

                        writer.WriteLine(textBox1.Text);
                   }
                }
                MessageBox.Show("Test");
            }
        }
    }
}
